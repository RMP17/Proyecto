<div class="container-fluid">
    
    <div class="card-group mb-0 ">
        <div class="card col-md-9 p-0">
            <div class="card-body p-0">
                <h5 class="card-title text-center">Detalle de la Compra</h5>
                <?php echo $__env->make('compra.forms.form_detalle_compra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="card col-md-3 border-0">
            <div class="card-body p-0">
                <h5 class="card-title text-center">Datos de Compra</h5>
                <?php echo $__env->make('compra.forms.form_compra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
    
</div>
