<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Inicio de Sesión</div>

                <div class="panel-body">
                    <div class="col-md-12 text-center">
                        <img src="<?php echo e(asset('images/tabletec-logo-2018.png')); ?>" width="400" class="img-responsive">
                    </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>" autocomplete="off">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            
                            <div class="col-md-10 col-md-offset-1">
                                <input id="email" type="text" placeholder="Nombre de Usuario" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <?php if(session('error_login')): ?>
                                    <span>
                                        <strong class="text-danger"><?php echo e(session('error_login')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            

                            <div class="col-md-10 col-md-offset-1">
                                <input id="password" placeholder="Contraseña"
                                       autocomplete="off"
                                       type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" class="" <?php echo e(old('remember') ? 'checked' : ''); ?>> Recordar mi cuenta
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-danger">
                                Iniciar Sesión
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>