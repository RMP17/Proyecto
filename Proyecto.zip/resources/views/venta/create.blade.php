<div class="container-fluid pr-0 pl-0">
	<div class="card-group mb-0 ">
		<div class="card col-md-8 p-0">
			<div class="card-body p-0">
				<h5 class="card-title text-center">Detalle de la Venta</h5>
				@include('venta.forms.form_detalle_venta')
			</div>
		</div>
		<div class="card col-md-4 border-0 pr-0 pl-0">
			<div class="card-body p-0">
				<h5 class="card-title text-center">Datos de Venta</h5>
				@include('venta.forms.form_venta')
			</div>
		</div>
	</div>
</div>